sudo yum install python-pip -y
sudo pip install flask

sudo python /web/web.py > /dev/null 2>&1 &
